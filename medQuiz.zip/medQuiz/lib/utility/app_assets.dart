class AppAssets {
  static String medquizicon = "assets/image/icon.png";
  static String medquizbelow = "assets/image/medquizbelow.png";
  static String medquizbelowwite = "assets/image/medquizbelowwhite.png";
  static String medquizcenter = "assets/image/medquizcenter.png";
  static String medquizright = "assets/image/medquizright.png";
}
