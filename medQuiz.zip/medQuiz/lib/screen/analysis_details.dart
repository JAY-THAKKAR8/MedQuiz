import 'package:flutter/material.dart';
import 'package:medquiz/utility/app_colors.dart';

class AnalysisDetails extends StatelessWidget {
  AnalysisDetails({Key? key}) : super(key: key);
  final items = ['Horse', 'Cow', 'Camel', 'Sheep', 'Goat'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Maths analysis details'),
          leading: GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: const Icon(
                Icons.arrow_back_ios,
                size: 15,
              )),
          backgroundColor: AppColor.primaryColor,
          centerTitle: true,
        ),
        body: ListView.builder(
          itemCount: items.length,
          itemBuilder: (context, index) {
            return Column(
              children: <Widget>[
                ListTile(
                  title: Text(items[index]),
                ),
                const Divider(), //                           <-- Divider
              ],
            );
          },
        ));
  }
}
